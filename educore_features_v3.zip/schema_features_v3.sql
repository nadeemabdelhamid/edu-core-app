-- ============================================================
-- EduCore: Feature Pack v3
-- 1. Center approval system (pending status)
-- 2. Grade notifications (uses existing notifications table)
-- 3. Question images
-- Safe to run multiple times (IF NOT EXISTS / MODIFY only adds)
-- ============================================================
USE educore_saas;

-- ─── 1. Center approval: add 'pending' to centers.status ────
ALTER TABLE centers
  MODIFY COLUMN status ENUM('active','suspended','trial','pending') DEFAULT 'trial';

-- ─── 2. Users: ensure is_active column exists ───────────────
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS is_active TINYINT(1) NOT NULL DEFAULT 1;

-- ─── 3. Question images ─────────────────────────────────────
ALTER TABLE exam_questions
  ADD COLUMN IF NOT EXISTS question_image VARCHAR(500) NULL DEFAULT NULL
    COMMENT 'URL to uploaded image for this question';

ALTER TABLE question_bank
  ADD COLUMN IF NOT EXISTS question_image VARCHAR(500) NULL DEFAULT NULL
    COMMENT 'URL to uploaded image for this question';

-- ─── 4. Notifications: ensure link column is long enough ────
ALTER TABLE notifications
  MODIFY COLUMN IF EXISTS link VARCHAR(500) NULL DEFAULT NULL;
